<?php 
    class Model {
        private $db;
        private $datos;

        public function __construct(){
            try{
                $this->db = new PDO("mysql:host=localhost;port=3306;dbname=tienda", "root", "");
                $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }catch(PDOException $err){
                echo $err;
            }
        }

        public function mostrar($tabla,$condicion){
            $show = $this->db->query("SELECT * FROM ".$tabla." WHERE ".$condicion.";");
            while($filas = $show->FETCHALL(PDO::FETCH_ASSOC)) {
                    $this->datos[]=$filas;
            }
            return $this->datos;
        }

        public function insertar($table, $data){
            $insert = $this->db->exec("INSERT INTO ".$table." VALUES(null,".$data.")");
            if($insert){
                echo true;
            }else {
                echo false;
            }
        }

        public function actualizar($tabla, $data, $condicion){
            $update = $this->db->exec("UPDATE ".$tabla." SET ". $data ." WHERE ".$condicion);
            if ($update) {
                return true;
            }else {
                return false;
            }
        }        
    }
?>
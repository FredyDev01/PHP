<?php     
    require_once("./config.php");        
    require_once("./controller/index.php");    
    
    $controller = new Controller();
    
    if(isset($_GET["url"]) && method_exists("Controller", $_GET["url"])){
        $controller->{$_GET["url"]}();
    }else{
        header("location:".currentPath."/inicio");
    }
?>
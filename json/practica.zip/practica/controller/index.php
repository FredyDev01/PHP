<?php 
    include_once('../model/index.php');

    class Controller {
        private $model;

        public function __construct(){
            $this->model = new Model();
        }

        static function inicio () {            
            include_once('../view/index.php');
        }

        static function agregar () {
            include_once('../view/agregar.php');
        }
    }
?>
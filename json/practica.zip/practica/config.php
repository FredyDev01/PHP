<?php 
    define("currentPath", "http://localhost:85/PHP/json/practica/index");
?>